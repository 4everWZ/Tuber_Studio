"""Current-batch observation probe; shared Model and image transforms are tracked."""
import argparse
import asyncio
import base64
import hashlib
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT))
from evaluations.vlm_images import prepare_image
from evaluations.vlm_operations import Model, error_record


async def main(args):
    manifest = json.loads(args.manifest.read_text())
    model = Model(args.base_url, args.model, thinking='on', max_tokens=4096,
                  temperature=.2, seed=42, timeout=300, response_format='none',
                  extra_body=dict(min_p=0., top_p=.95, top_k=40, repeat_penalty=1., presence_penalty=0.))
    report = dict(condition='plain_visual_observation_same_frames_v1',
                  question='图中主要人物、物品和动作是什么？',
                  tools=False, response_format='none', oc_character=False, input_order='image_first',
                  parent_manifest_sha256=hashlib.sha256(args.manifest.read_bytes()).hexdigest(),
                  helper_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                  shared_source_sha256={str(path):hashlib.sha256((ROOT/path).read_bytes()).hexdigest()
                      for path in ('evaluations/vlm_operations.py','evaluations/vlm_images.py')},
                  frames=[], semantic_review='pending', platform_messages_sent=0,
                  production_configuration_written=False)

    def save():
        args.output.write_text(json.dumps(report, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')

    try:
        report['model_metadata'] = await model.metadata()
        assert report['model_metadata']['observed_context_tokens'] == 131072
        assert report['model_metadata']['model_alias_matches']
        for frame in manifest['frames']:
            path = (args.manifest.parent/frame['file']).resolve()
            assert path.is_relative_to(args.manifest.parent.resolve())
            original = path.read_bytes()
            assert hashlib.sha256(original).hexdigest() == frame['image_sha256']
            image = prepare_image(original, frame['mime_type'], args.image_preprocessing)
            item = {key:frame[key] for key in ('id','cid','actual_time','image_sha256')}
            item['input_image'] = image['metadata']
            content = [dict(type='image_url',image_url=dict(url='data:'+image['mime_type']+';base64,'+
                       base64.b64encode(image['data']).decode())),dict(type='text',text=report['question'])]
            try:
                item['model_response'] = await model.generate([dict(role='user', content=content)], tools=False)
            except Exception as error:
                item['error'] = error_record(error)
                item['partial_response'] = getattr(error, 'model_step', None)
            report['frames'].append(item)
            save()
    finally:
        await model.close()
        save()


if __name__ == '__main__':
    p=argparse.ArgumentParser()
    p.add_argument('--model',required=True)
    p.add_argument('--base-url',default='http://127.0.0.1:18096')
    p.add_argument('--image-preprocessing',default='server_native')
    p.add_argument('--manifest',type=Path,default=ROOT/'tmp/operations-vlm/platform-real/storyboard-report.json')
    p.add_argument('--output',type=Path,required=True)
    asyncio.run(main(p.parse_args()))
