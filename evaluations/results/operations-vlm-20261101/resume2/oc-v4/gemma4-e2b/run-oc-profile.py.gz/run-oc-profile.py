"""Explicit natural OC profile invocation, native tools and original replies without format repair."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys

sampling=Path('tmp/operations-vlm/resume2/v3-sampling.json')
sampling.write_bytes((json.dumps(dict(min_p=0.0,top_p=.95,top_k=40,repeat_penalty=1.0,presence_penalty=0.0))+'\n').encode())
command=[sys.executable,'evaluations/vlm_operations.py',
 '--base-url','http://127.0.0.1:18096','--context-tokens','131072','--thinking','on',
 '--max-output-tokens','4096','--tools-mode','native','--tool-reasoning-history','ephemeral',
 '--temperature','0.2','--seed','42','--extra-body-json',str(sampling),
 '--network-proxy','http://127.0.0.1:7897','--character-file','config/characters.json',
 '--bvid','BV1We4y1k7za','--image-manifest','tmp/operations-vlm/platform-real/storyboard-report.json',
 *sys.argv[1:]]
assert '--format-repair' not in command
out=Path(command[command.index('--output')+1])
out.parent.mkdir(parents=True,exist_ok=True)
metadata=dict(command=command[1:],git_revision=subprocess.run(['git','rev-parse','HEAD'],capture_output=True,check=True,text=True).stdout.strip(),
              format_repair=False,source_files={name:hashlib.sha256(Path(name).read_bytes()).hexdigest() for name in
                 ['evaluations/vlm_operations.py','evaluations/cases/vlm-operations.json','config/characters.json']})
out.with_suffix('.command.json').write_bytes((json.dumps(metadata,ensure_ascii=False,indent=2)+'\n').encode())
raise SystemExit(subprocess.call(command))
