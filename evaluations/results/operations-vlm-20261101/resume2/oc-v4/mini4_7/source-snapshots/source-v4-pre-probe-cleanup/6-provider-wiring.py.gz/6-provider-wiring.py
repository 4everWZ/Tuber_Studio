"""Prepare or execute one isolated public ApiVideoEvidenceProvider linkage.

Default mode reads local artifacts only. --execute is for the device controller.
"""

# ruff: noqa: E402 -- repo-local entrypoint bootstraps imports before loading project modules.

import argparse
import asyncio
import hashlib
import json
import os
import sys
import time
from contextlib import contextmanager
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
WORKSPACE = ROOT / "tmp/operations-vlm"
sys.path.insert(0, str(ROOT))

from evaluations.vlm_operations import load_asset_images, strip_thought_prefix
from tuber_studio.browsing_models import BrowsingPolicy
from tuber_studio.config import Settings
from tuber_studio.http_api import endpoint
from tuber_studio.runtime import Runtime
from tuber_studio.store import Store
from tuber_studio.video_vision import ApiVideoEvidenceProvider, VideoVisionConfig


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def require(condition, message):
    if not condition:
        raise ValueError(message)


def pointer(value, path):
    for part in path.strip("/").split("/") if path else []:
        part = part.replace("~1", "/").replace("~0", "~")
        value = value[int(part)] if isinstance(value, list) else value[part]
    return value


def source_record(path):
    return {"path": str(path.resolve()), "sha256": sha(path.read_bytes())}


def prepare(args):
    for path in (args.output, args.runtime):
        require(
            path.resolve().is_relative_to(WORKSPACE.resolve()),
            "Output and isolated runtime must stay in tmp/operations-vlm",
        )
    require(not args.output.exists(), "Choose a fresh output filename")
    registry = read(args.registry)
    profile = registry["profiles"][args.profile]
    owner, metrics = read(args.owner), read(args.metrics)
    guard_mib = metrics.get("parameters", {}).get("min_available_mib")
    owner_command = owner.get("runner", {}).get("command", [])
    if guard_mib is None and "--min-available-mib" in owner_command:
        guard_mib = float(owner_command[owner_command.index("--min-available-mib") + 1])
    minimum_available = metrics.get("memory", {}).get("minimum_system_available_bytes")
    within_guard = (
        minimum_available >= guard_mib * 1024**2
        if guard_mib is not None and minimum_available is not None
        else None
    )
    require(metrics["profile"] == args.profile, "Metrics profile differs from requested candidate")
    require(
        owner["server"]["pid"] == metrics["server_pid"], "Owner/metrics refer to different server processes"
    )
    props = metrics["actual_props"]
    aliases = props["model_alias"]
    aliases = [aliases] if isinstance(aliases, str) else aliases
    require(args.model in aliases, "Metrics model alias differs from requested model")
    require(metrics["actual_context_tokens"] == 131072, "Actual runtime slot must be 131072")
    for role in ("model", "projector"):
        artifact = metrics["artifacts"][role]
        require(artifact.get("sha256_verified") is True, f"{role} bytes were not verified")
        require(
            artifact["sha256"] == profile["artifacts"][role]["sha256"],
            f"{role} differs from selected registry profile",
        )
    require(len(metrics["binary_sha256"]) == 64, "Actual runtime binary SHA is missing")
    _, records = load_asset_images(manifest_path=args.manifest)
    manifest = read(args.manifest)
    require(len(records) == 3, "This linkage uses the three verified storyboard frames")
    frames = [
        dict(entry, image=Path(record["path"]).read_bytes())
        for entry, record in zip(manifest["frames"], records, strict=True)
    ]
    metadata = pointer(read(args.metadata_report), args.metadata_pointer)
    require(metadata["bvid"] == manifest["bvid"], "Video metadata and storyboard BV differ")
    durations = {str(part["cid"]): part["duration"] for part in metadata["parts"]}
    require(
        all(
            str(frame["cid"]) in durations and frame["actual_time"] <= durations[str(frame["cid"])]
            for frame in frames
        ),
        "Frame CID/time does not match verified video metadata",
    )
    config = VideoVisionConfig.model_validate(
        dict(
            enabled=True,
            base_url=endpoint(args.base_url),
            model=args.model,
            model_revision=profile["conversion_revision"] + ":" + metrics["artifacts"]["model"]["sha256"],
            projector_revision=profile["conversion_revision"]
            + ":"
            + metrics["artifacts"]["projector"]["sha256"],
            runtime_revision=metrics["binary_sha256"],
            runtime_profile=args.profile + ":" + owner["experiment_id"],
            context_tokens=131072,
            native_context_tokens=profile["native_context_tokens"],
            max_frames=3,
            max_pixels=max(frame["width"] * frame["height"] for frame in frames),
            max_bytes=sum(len(frame["image"]) for frame in frames),
            max_output_tokens=getattr(args, "max_output_tokens", 4096),
            enable_thinking=True,
            sampling=read(args.sampling_json) if getattr(args, "sampling_json", None) else {},
            timeout_seconds=args.timeout_seconds,
        )
    )
    identity = config.model_dump(exclude={"enabled", "timeout_seconds"})
    inputs = {
        key: source_record(getattr(args, key))
        for key in ("registry", "owner", "metrics", "manifest", "metadata_report")
    }
    if getattr(args, "sampling_json", None):
        inputs["sampling_json"] = source_record(args.sampling_json)
    report = dict(
        mode="execute" if args.execute else "local_plan_only",
        provider_configuration=config.model_dump(),
        public_provider_identity=identity,
        inputs=inputs,
        run_id=owner["experiment_id"],
        resource_state=metrics["state"],
        resource_memory={
            "declared_min_available_mib": guard_mib,
            "minimum_observed_available_bytes": minimum_available,
            "within_declared_guard": within_guard,
            "run_parameters": metrics.get("parameters", {}),
            "owner_runner_command": owner_command,
        },
        metadata_pointer=args.metadata_pointer,
        frames=[
            {key: frame[key] for key in ("id", "cid", "actual_time", "image_sha256", "width", "height")}
            for frame in frames
        ],
        input_image_preprocessing="server_native_original_bytes",
        requests=[],
        stages=[],
        input_order="existing_provider_text_first",
        sampling_source="explicit_sampling_json"
        if getattr(args, "sampling_json", None)
        else "compatible_default_temperature_0.2_otherwise_service_defaults",
        response_mode="existing_APIProvider_json_object",
        served_default_sampling=metrics["actual_props"]
        .get("default_generation_settings", {})
        .get("params", {}),
        runtime_directory=str(args.runtime.resolve()),
        helper_sha256=sha(Path(__file__).read_bytes()),
        software_sha256={
            name: sha((ROOT / "src/tuber_studio" / name).read_bytes())
            for name in ("video_vision.py", "api_providers.py", "llama_sampling.py")
        },
        platform_messages_sent=0,
        production_configuration_written=False,
        semantic_review="pending",
        question=args.question,
        round_deadline_seconds=1800,
    )
    proof = None
    if args.resource_proof:
        proof = read(args.resource_proof)
        measurement = proof["measurement"]
        require(proof.get("passed") is True, "Resource proof is not a passed device measurement")
        require(
            proof.get("configuration") == identity,
            "Resource proof configuration differs from this public identity",
        )
        require(proof.get("context_tokens") == 131072, "Resource proof has a different window")
        for key in ("max_frames", "max_pixels", "max_bytes"):
            require(
                type(proof.get(key)) is int and proof[key] >= getattr(config, key),
                f"Resource proof does not cover {key}",
            )
        require(measurement["run_id"] == owner["experiment_id"], "Resource proof belongs to a different run")
        for key in ("owner", "metrics", "manifest"):
            require(
                measurement[key + "_sha256"] == inputs[key]["sha256"],
                f"Resource proof {key} snapshot differs",
            )
        require(measurement.get("evidence"), "Supply actual same-run resource evidence artifact references")
        for evidence in measurement["evidence"]:
            require(
                sha(Path(evidence["path"]).read_bytes()) == evidence["sha256"],
                "Resource evidence artifact changed",
            )
        report["resource_proof"] = proof
        report["inputs"]["resource_proof"] = source_record(args.resource_proof)
    if args.execute:
        require(proof is not None, "Execution needs an explicit matching --resource-proof")
        require(metrics["state"] == "ready", "Execution needs a current ready-run metrics snapshot")
        require(
            within_guard is not False,
            "Resource snapshot crossed this run's declared available-memory guard",
        )
        require(not args.runtime.exists(), "Execution needs a fresh isolated runtime directory")
    return config, frames, metadata, report, proof


@contextmanager
def isolated_environment(runtime_dir):
    values = {
        "TUBER_CONFIG": str(runtime_dir / "studio.json"),
        "TUBER_RUNTIME": str(runtime_dir),
        "TUBER_ADMIN_TOKEN": "isolated-provider-linkage-only",
    }
    previous = {key: os.environ.get(key) for key in values}
    os.environ.update(values)
    try:
        yield
    finally:
        for key, value in previous.items():
            if value is None:
                os.environ.pop(key, None)
            else:
                os.environ[key] = value


def save(args, report):
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


async def execute(args, config, frames, metadata, report, proof):
    args.runtime.mkdir(parents=True, exist_ok=False)
    data = read(ROOT / "config/studio.example.json")
    data["llm"]["kind"] = "demo"
    data["tts"]["kind"] = "prerecorded"
    data["vision"] = {"kind": "disabled"}
    data.setdefault("features", {})["live_enabled"] = False
    data.setdefault("inference_broker", {})["enabled"] = False
    data.setdefault("song_requests", {})["enabled"] = False
    (args.runtime / "studio.json").write_text(json.dumps(data), encoding="utf-8")
    with isolated_environment(args.runtime):
        settings = Settings(root=ROOT, runtime=args.runtime)
    store = Store(args.runtime / "evaluation.sqlite3", read(ROOT / "config/characters.json"))
    runtime = Runtime(settings, store)  # No Runtime.open(), workers or platform adapters.
    provider = ApiVideoEvidenceProvider(
        runtime, config.model_dump(), api_key=os.getenv(args.api_key_env) or None
    )

    async def observe(response):
        if not response.request.url.path.endswith("/chat/completions"):
            return
        await response.aread()
        payload = json.loads(response.request.content)
        row = dict(
            request_sha256=sha(response.request.content),
            http_status=response.status_code,
            max_tokens=payload.get("max_tokens"),
            request_thinking=payload.get("chat_template_kwargs"),
            temperature=payload.get("temperature"),
            request_seed=payload.get("seed"),
            request_sampling={
                key: payload[key] for key in type(config.sampling).model_fields if key in payload
            },
            tools_present="tools" in payload,
            response_format=payload.get("response_format"),
        )
        try:
            result = response.json()
            choice = (result.get("choices") or [{}])[0]
            message = choice.get("message") or {}
            raw = message.get("content") or ""
            try:
                visible, removed = strip_thought_prefix(raw)
            except ValueError:
                visible, removed = "", len(raw)
            row.update(
                finish_reason=choice.get("finish_reason"),
                usage=result.get("usage"),
                visible_content=visible,
                reasoning_characters_not_retained=len(message.get("reasoning_content") or "") + removed,
            )
        except (ValueError, TypeError):
            row["response_decoding"] = "unavailable"
        report["requests"].append(row)
        save(args, report)

    provider.api.client.event_hooks["response"].append(observe)
    policy = BrowsingPolicy(
        deadline_seconds=1800,
        decision_max_tokens=config.max_output_tokens,
        max_model_calls=8,
        max_output_tokens=32768,
        max_input_tokens=1048576,
    ).model_dump()
    row, _ = runtime.browsing_repository.create_round(
        "isolated-provider-linkage", runtime.character, policy, 0, True
    )
    task = {"id": "storyboard-linkage", "round_id": row["id"]}
    report["round_policy"] = policy
    try:
        started = time.perf_counter()
        probe = await provider.probe(
            frames,
            metadata=metadata,
            resource_admission=proof,
            task=task,
            deadline=min(row["deadline"], time.time() + config.timeout_seconds),
        )
        report["stages"].append(
            {
                "name": "public_probe_and_resource_admission",
                "value": probe,
                "elapsed_ms": (time.perf_counter() - started) * 1000,
            }
        )
        save(args, report)
        require(
            probe["properties"].get("model_path") == read(args.metrics)["actual_props"].get("model_path"),
            "Public endpoint model path differs from supplied run",
        )
        require(
            probe["capabilities"]["admitted"], "Public probe did not admit the provided resource evidence"
        )
        result = await provider.analyze_video_evidence(
            task,
            metadata,
            frames,
            args.question,
            deadline=min(row["deadline"], time.time() + config.timeout_seconds),
        )
        report["stages"].append({"name": "public_analyze_video_evidence", "value": result})
        sources = {frame["id"]: frame for frame in frames}
        report["bound_observations"] = [
            {
                "frame_id": identity,
                "bvid": metadata["bvid"],
                "cid": sources[identity]["cid"],
                "actual_time": sources[identity]["actual_time"],
                "image_sha256": sources[identity]["image_sha256"],
                "observation": result["frame_observations"][identity],
            }
            for identity in result["evidence_ids"]
        ]
        report["model_sufficiency_assessment"] = result["sufficient"]
        runtime.browsing_repository.finish_round(row["id"], "completed")
    except Exception as error:
        report["error"] = {"kind": type(error).__name__, "message": str(error)}
        runtime.browsing_repository.finish_round(row["id"], "failed", error=str(error))
    finally:
        report["round_budget"] = runtime.browsing_repository.round(row["id"])["budget"]
        await provider.close()
        await runtime.close()
        store.close()
        save(args, report)


def arguments():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--profile", required=True)
    parser.add_argument("--model", required=True)
    parser.add_argument("--base-url", required=True, help="Controller-owned current endpoint including /v1")
    parser.add_argument("--owner", type=Path, required=True)
    parser.add_argument("--metrics", type=Path, required=True, help="Immutable snapshot from the same run")
    parser.add_argument("--registry", type=Path, default=ROOT / "evaluations/candidates/vlm-operations.json")
    parser.add_argument("--manifest", type=Path, default=WORKSPACE / "platform-real/storyboard-report.json")
    parser.add_argument("--metadata-report", type=Path, required=True)
    parser.add_argument("--metadata-pointer", default="/cases/0/tool_receipts/0/result/metadata")
    parser.add_argument("--timeout-seconds", type=float, default=300)
    parser.add_argument("--max-output-tokens", type=int, default=4096)
    parser.add_argument("--sampling-json", type=Path, help="Explicit VideoVisionConfig sampling object")
    parser.add_argument("--question", default="逐帧描述画面中的人物、物品和动作，并概括这些抽样画面。")
    parser.add_argument("--resource-proof", type=Path)
    parser.add_argument("--api-key-env", default="TUBER_EVAL_VISION_API_KEY")
    parser.add_argument("--runtime", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--execute", action="store_true")
    return parser.parse_args()


if __name__ == "__main__":
    args = arguments()
    config, frames, metadata, report, proof = prepare(args)
    save(args, report)
    if args.execute:
        asyncio.run(execute(args, config, frames, metadata, report, proof))
    print(
        json.dumps(
            {"output": str(args.output), "mode": report["mode"], "error": report.get("error")},
            ensure_ascii=False,
        )
    )
    raise SystemExit(1 if report.get("error") else 0)
