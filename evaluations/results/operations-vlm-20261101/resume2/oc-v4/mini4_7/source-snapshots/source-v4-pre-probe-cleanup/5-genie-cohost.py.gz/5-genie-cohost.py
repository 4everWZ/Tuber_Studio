"""One foreground, owned Genie worker beside the already-owned candidate.

Runs only on the Jetson container. No broker mode/config update, platform or playback.
"""
import argparse
import array
import hashlib
import io
import json
import os
import secrets
import signal
import socket
import subprocess
import sys
import threading
import time
import wave
from datetime import datetime, timezone
from pathlib import Path

import httpx
import psutil

p = argparse.ArgumentParser()
p.add_argument('--run-dir', type=Path, required=True)
p.add_argument('--model-run', type=Path, required=True)
p.add_argument('--model', required=True)
p.add_argument('--messages', type=Path, required=True)
p.add_argument('--min-available-mib', type=int, default=512)
p.add_argument('--max-swap-growth-mib', type=int, default=128)
args = p.parse_args()
root = Path('/workspace/tuber')
allowed = root/'runtime/experiments/operations-vlm-20261101/resume2'
out = args.run_dir.resolve()
assert out.is_relative_to(allowed) and not out.exists()
out.mkdir(mode=0o700)
assert args.model_run.resolve().is_relative_to(allowed)
owner = json.loads((args.model_run/'owner.json').read_text())
initial_metrics = json.loads((args.model_run/'metrics.json').read_text())
assert initial_metrics['state'] == 'ready'
candidate_pid = owner['server']['pid']
candidate = psutil.Process(candidate_pid)
candidate_stamp = candidate.create_time()
config = root/'runtime/studio.json'
config_sha = hashlib.sha256(config.read_bytes()).hexdigest()
before = json.loads((allowed.parent/'before.json').read_text())
assert config_sha == before['config_sha256']
messages_data = json.loads(args.messages.read_text())
messages = messages_data['messages']
assert all(m['role'] in ('user', 'system') for m in messages)
report = dict(purpose='Owned Mini VLM plus existing fixed-voice Genie CPU worker, sequential business-shaped inference',
              created_at=datetime.now(timezone.utc).isoformat(), model=args.model,
              model_run=str(args.model_run), candidate_pid=candidate_pid,
              candidate_create_time=candidate_stamp,
              candidate_owner_sha256=hashlib.sha256((args.model_run/'owner.json').read_bytes()).hexdigest(),
              candidate_context_tokens=initial_metrics['actual_context_tokens'],
              configuration_sha256_before=config_sha, production_configuration_written=False,
              broker_mode_changed=False, platform_messages_sent=0, audio_playback=False,
              helper_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              messages_sha256=hashlib.sha256(args.messages.read_bytes()).hexdigest(),
              parameters=dict(min_available_mib=args.min_available_mib,
                              max_swap_growth_mib=args.max_swap_growth_mib), phases={}, cleanup={})
baseline_swap = psutil.swap_memory().used
worker = None
worker_stamp = None
phase = 'before_tts'
stop_monitor = threading.Event()
guard_failed = threading.Event()
samples = []
nonce = secrets.token_hex(24)

def save():
    tmp = out/'result.tmp.json'
    tmp.write_text(json.dumps(report, ensure_ascii=False, indent=2)+'\n')
    tmp.replace(out/'result.json')

def rss(pid):
    try:
        proc = psutil.Process(pid)
        return proc.memory_info().rss if proc.status() != psutil.STATUS_ZOMBIE else 0
    except (psutil.NoSuchProcess, psutil.AccessDenied):
        return 0

def owned_signal(sig):
    if worker is None or worker.poll() is not None:
        return
    try:
        proc = psutil.Process(worker.pid)
        if proc.status() == psutil.STATUS_ZOMBIE:
            return
        if proc.create_time() != worker_stamp or proc.environ().get('TUBER_COHOST_OWNER') != nonce:
            if worker.poll() is not None or proc.status() == psutil.STATUS_ZOMBIE:
                return
            raise RuntimeError('Refusing to signal a changed Genie worker identity')
        os.killpg(worker.pid, sig)
    except (ProcessLookupError, psutil.NoSuchProcess):
        return

def monitor():
    with (out/'memory.jsonl').open('a') as handle:
        while not stop_monitor.is_set():
            mem, swap = psutil.virtual_memory(), psutil.swap_memory()
            item = dict(timestamp=datetime.now(timezone.utc).isoformat(), monotonic=time.monotonic(),
                        phase=phase, system_available_bytes=mem.available, system_used_bytes=mem.used,
                        swap_used_bytes=swap.used, swap_in_bytes=swap.sin, swap_out_bytes=swap.sout,
                        candidate_rss_bytes=rss(candidate_pid), worker_rss_bytes=rss(worker.pid) if worker else 0)
            samples.append(item)
            handle.write(json.dumps(item)+'\n')
            handle.flush()
            if (mem.available < args.min_available_mib*1048576 or
                    swap.used-baseline_swap > args.max_swap_growth_mib*1048576):
                report['resource_guard'] = dict(triggered=True, sample=item)
                guard_failed.set()
                owned_signal(signal.SIGTERM)
            stop_monitor.wait(.5)

thread = threading.Thread(target=monitor, daemon=True)
log = (out/'worker.log').open('wb')
thread.start()
try:
    with socket.socket() as listener:
        listener.bind(('127.0.0.1', 9041))
    command = [sys.executable, str(root/'tools/jetson/tts/server.py'), '-a', '127.0.0.1', '-p', '9041']
    env = os.environ.copy()
    env.update(TUBER_ROOT=str(root), TUBER_COHOST_OWNER=nonce, PYTHONDONTWRITEBYTECODE='1',
               NUMBA_CACHE_DIR=str(out/'numba-cache'))
    phase = 'tts_loading'
    started = time.monotonic()
    worker = subprocess.Popen(command, cwd=root, env=env, stdout=log, stderr=subprocess.STDOUT,
                              start_new_session=True)
    worker_stamp = psutil.Process(worker.pid).create_time()
    report['worker'] = dict(pid=worker.pid, create_time=worker_stamp, command=command, port=9041,
                            production_tts_port=9011, independent_owned_worker=True)
    save()
    with httpx.Client(trust_env=False, timeout=300) as client:
        while time.monotonic()-started < 240:
            if worker.poll() is not None or guard_failed.is_set():
                raise RuntimeError('Owned Genie worker exited or resource guard fired during startup')
            try:
                health = client.get('http://127.0.0.1:9041/docs', timeout=3)
                if health.status_code == 200:
                    identity = health.json()
                    assert identity['backend'] == 'genie_onnx_int8' and identity['status'] == 'ready'
                    break
            except httpx.HTTPError:
                pass
            time.sleep(.5)
        else:
            raise TimeoutError('Owned Genie worker readiness deadline')
        report['worker'].update(ready_seconds=time.monotonic()-started, identity=identity)
        save()
        assert candidate.create_time() == candidate_stamp and candidate.is_running()
        props = client.get('http://127.0.0.1:9030/props').raise_for_status().json()
        assert props['model_alias'] == args.model
        assert props['default_generation_settings']['n_ctx'] == 131072
        assert not any(s['is_processing'] for s in client.get('http://127.0.0.1:9030/slots').raise_for_status().json())
        phase = 'llm_with_genie_resident'
        payload = dict(model=args.model, messages=messages, stream=False, max_tokens=4096,
                       temperature=.2, seed=42, top_p=.95, top_k=40, min_p=0,
                       repeat_penalty=1., presence_penalty=0., chat_template_kwargs={'enable_thinking': True})
        started = time.monotonic()
        response = client.post('http://127.0.0.1:9030/v1/chat/completions', json=payload)
        response.raise_for_status()
        data = response.json()
        choice = data['choices'][0]
        message = choice['message']
        text = message.get('content') or ''
        report['llm'] = dict(text=text, usage=data.get('usage'), finish_reason=choice.get('finish_reason'),
                             elapsed_seconds=time.monotonic()-started, reasoning_characters=len(message.get('reasoning_content') or ''),
                             request_parameters={k:v for k,v in payload.items() if k != 'messages'})
        assert choice.get('finish_reason') == 'stop' and text.strip() and len(text) <= 1000
        save()
        phase = 'speech_with_vlm_resident'
        started = time.monotonic()
        speech = client.post('http://127.0.0.1:9041/tts', json=dict(text=text, text_lang='zh', seed=42, streaming_mode=False))
        speech.raise_for_status()
        audio = speech.content
        with wave.open(io.BytesIO(audio), 'rb') as wav:
            wav_meta = dict(channels=wav.getnchannels(), sample_width=wav.getsampwidth(), rate=wav.getframerate(),
                            frames=wav.getnframes(), seconds=wav.getnframes()/wav.getframerate())
            pcm = wav.readframes(wav.getnframes())
        assert wav_meta['channels'] == 1 and wav_meta['sample_width'] == 2
        peak = max(abs(v) for v in array.array('h', pcm))
        assert peak > 0
        (out/'local-speech.wav').write_bytes(audio)
        report['speech'] = dict(**wav_meta, bytes=len(audio), sha256=hashlib.sha256(audio).hexdigest(),
                                pcm_peak=peak, elapsed_seconds=time.monotonic()-started, text=text,
                                endpoint='loopback-owned-worker', played=False)
        phase = 'pair_completed'
        assert candidate.create_time() == candidate_stamp and candidate.is_running() and worker.poll() is None
        report['pair_completed'] = True
        save()
except BaseException as error:
    report['error'] = dict(kind=type(error).__name__, message=str(error))
    report['pair_completed'] = False
finally:
    phase = 'cleanup_owned_tts'
    if worker is not None:
        owned_signal(signal.SIGTERM)
        try:
            worker.wait(timeout=20)
        except subprocess.TimeoutExpired:
            owned_signal(signal.SIGKILL)
            worker.wait(timeout=10)
        report['cleanup'].update(worker_returncode=worker.returncode, owned_worker_reaped=True)
    stop_monitor.set()
    thread.join(timeout=3)
    log.close()
    for name in {s['phase'] for s in samples}:
        subset = [s for s in samples if s['phase'] == name]
        report['phases'][name] = dict(samples=len(subset), minimum_available_bytes=min(s['system_available_bytes'] for s in subset),
            peak_combined_rss_bytes=max(s['candidate_rss_bytes']+s['worker_rss_bytes'] for s in subset),
            peak_swap_growth_bytes=max(0,max(s['swap_used_bytes'] for s in subset)-baseline_swap))
    report['configuration_sha256_after'] = hashlib.sha256(config.read_bytes()).hexdigest()
    report['configuration_unchanged'] = report['configuration_sha256_after'] == config_sha
    try:
        report['cleanup']['candidate_left_running'] = (candidate.create_time() == candidate_stamp and
            candidate.is_running() and candidate.status() != psutil.STATUS_ZOMBIE)
    except psutil.NoSuchProcess:
        report['cleanup']['candidate_left_running'] = False
    save()
    print(json.dumps({k:report.get(k) for k in ('pair_completed','error','speech','configuration_unchanged','cleanup')}, ensure_ascii=False))
