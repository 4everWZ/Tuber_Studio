"""Restore the captured original residency after all owned candidate work stops."""
import argparse
import hashlib
import json
import socket
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

import httpx
import psutil

p=argparse.ArgumentParser()
p.add_argument('--output-dir',type=Path,required=True)
args=p.parse_args()
root=Path('/workspace/tuber/runtime')
experiment=root/'experiments/operations-vlm-20261101'
out=args.output_dir.resolve()
assert out.is_relative_to(experiment/'resume2')
out.mkdir(mode=0o700)
before=json.loads((experiment/'before.json').read_text())
data=dict(created_at=datetime.now(timezone.utc).isoformat(),
          configuration_sha256_before=hashlib.sha256((root/'studio.json').read_bytes()).hexdigest(),
          platform_messages_sent=0,production_configuration_written=False,
          restoration_script_sha256=hashlib.sha256((experiment/'restore.py').read_bytes()).hexdigest(),
          verification_helper_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())

def processes():
    found=[]
    for process in psutil.process_iter(['pid','name','status','cmdline']):
        try:
            info=process.info
            if info['name']!='llama-server' or info['status']==psutil.STATUS_ZOMBIE:
                continue
            command=info['cmdline'] or []
            alias=command[command.index('--alias')+1] if '--alias' in command else None
            found.append(dict(pid=process.pid,alias=alias,create_time=process.create_time(),
                              experimental=any('/models/operations-vlm/' in arg for arg in command)))
        except (psutil.NoSuchProcess,psutil.AccessDenied):
            continue
    return found

def port_open(port):
    with socket.socket() as sock:
        sock.settimeout(1)
        return sock.connect_ex(('127.0.0.1',port))==0

try:
    assert data['configuration_sha256_before']==before['config_sha256']
    data['processes_before']=processes()
    assert not any(item['experimental'] for item in data['processes_before'])
    data['owned_genie_port9041_open_before']=port_open(9041)
    assert not data['owned_genie_port9041_open_before']
    if (experiment/'restored.json').exists():
        (out/'restored-before-final.json').write_bytes((experiment/'restored.json').read_bytes())
    with httpx.Client(base_url='http://127.0.0.1:9012',trust_env=False,timeout=20,
                     headers={'X-Tuber-Inference-Key':(root/'inference-token').read_text().strip()}) as client:
        data['broker_before']=client.get('/health').raise_for_status().json()
        assert data['broker_before']['mode']==before['broker']['mode']
        result=subprocess.run([sys.executable,str(experiment/'restore.py')],capture_output=True,timeout=300)
        data['restoration_returncode']=result.returncode
        if result.returncode:
            raise RuntimeError('Captured original-model restoration command failed')
        (out/'restored.json').write_bytes((experiment/'restored.json').read_bytes())
        data['broker_after']=client.get('/health').raise_for_status().json()
        current=data['broker_after']
        assert current['mode']==before['broker']['mode']
        assert current['selected_provider']==before['broker']['selected_provider']
        for key,expected in before['broker']['providers'].items():
            assert current['providers'][key]['running']==expected['running'],key
        selected=before['broker']['selected_provider']
        route={'llm2b':'2b','llm1b':'1b','llm1bq8':'1bq8','llmqwen35':'qwen35'}[selected]
        health=client.get('/llm/'+route+'/health').raise_for_status().json()
        data['original_llm_direct_health']=health
    data['processes_after']=processes()
    assert not any(item['experimental'] for item in data['processes_after'])
    assert data['processes_after']
    data['configuration_sha256_after']=hashlib.sha256((root/'studio.json').read_bytes()).hexdigest()
    assert data['configuration_sha256_after']==before['config_sha256']
    data['ram']=psutil.virtual_memory()._asdict()
    data['swap']=psutil.swap_memory()._asdict()
    data['owned_genie_port9041_open_after']=port_open(9041)
    assert not data['owned_genie_port9041_open_after']
    data['restoration_verified']=True
except BaseException as error:
    data['error']=dict(kind=type(error).__name__,message=str(error))
    data['restoration_verified']=False
finally:
    (out/'verification.json').write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({k:data.get(k) for k in ('restoration_verified','error','configuration_sha256_after','processes_after')},ensure_ascii=False))
if not data['restoration_verified']:
    sys.exit(1)
