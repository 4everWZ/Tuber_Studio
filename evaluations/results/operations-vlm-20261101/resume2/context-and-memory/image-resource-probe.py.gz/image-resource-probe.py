"""Three unchanged real frames, one discarded output token: resources only."""
import argparse
import base64
import hashlib
import json
import time
from datetime import datetime, timezone
from pathlib import Path

import httpx

p=argparse.ArgumentParser()
p.add_argument('--model',required=True)
p.add_argument('--base-url',default='http://127.0.0.1:18096')
p.add_argument('--context-tokens',type=int,default=131072)
p.add_argument('--manifest',type=Path,default=Path('tmp/operations-vlm/platform-real/storyboard-report.json'))
p.add_argument('--output',type=Path,required=True)
args=p.parse_args()
manifest=json.loads(args.manifest.read_text())
content=[]
for frame in manifest['frames']:
    path=(args.manifest.parent/frame['file']).resolve()
    assert path.is_relative_to(args.manifest.parent.resolve())
    data=path.read_bytes()
    assert hashlib.sha256(data).hexdigest()==frame['image_sha256']
    content.append({'type':'image_url','image_url':{'url':'data:'+frame['mime_type']+';base64,'+base64.b64encode(data).decode()}})
content.append({'type':'text','text':'看图。'})
payload=dict(model=args.model,messages=[dict(role='user',content=content)],max_tokens=1,stream=False,temperature=0,
             chat_template_kwargs={'enable_thinking':True},reasoning_format='deepseek')
body=json.dumps(payload,ensure_ascii=False,separators=(',',':')).encode()
report=dict(purpose='Resource-only three-frame encode; one output token discarded, no answer quality evaluation',
            started_at=datetime.now(timezone.utc).isoformat(),model=args.model,configured_context_tokens=args.context_tokens,
            manifest_sha256=hashlib.sha256(args.manifest.read_bytes()).hexdigest(),input_order='image_first',
            frames=[{k:f[k] for k in ('id','actual_time','image_sha256','width','height','bytes')} for f in manifest['frames']],
            payload_sha256=hashlib.sha256(body).hexdigest(),max_tokens=1,thinking=True,quality_cases=0)
started=time.perf_counter()
try:
    with httpx.Client(base_url=args.base_url,timeout=900,trust_env=False) as client:
        props=client.get('/props').raise_for_status().json()
        assert props['model_alias']==args.model
        assert props['default_generation_settings']['n_ctx']==args.context_tokens
        assert not any(slot['is_processing'] for slot in client.get('/slots').raise_for_status().json())
        r=client.post('/v1/chat/completions',content=body,headers={'Content-Type':'application/json'})
        report['http_status']=r.status_code
        r.raise_for_status()
        data=r.json()
        choice=data['choices'][0]
        report.update(usage=data.get('usage'),finish_reason=choice.get('finish_reason'),
                      reasoning_characters=len(choice.get('message',{}).get('reasoning_content') or ''),
                      response_content_retained=False,request_succeeded=True)
except Exception as error:
    report.update(request_succeeded=False,error=dict(kind=type(error).__name__,message=str(error)))
finally:
    report['elapsed_ms']=(time.perf_counter()-started)*1000
    args.output.write_bytes((json.dumps(report,ensure_ascii=False,indent=2)+'\n').encode())
    print(json.dumps(report,ensure_ascii=False))
